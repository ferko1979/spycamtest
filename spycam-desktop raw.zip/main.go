package main

import (
	"context"
	"embed"
	"encoding/base64"
	"encoding/json"
	"flag"
	"fmt"
	"net"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strings"
	"sync"
	"time"

	"github.com/getlantern/systray"
	"github.com/pkg/browser"
	webview "github.com/webview/webview_go"
)

// Must exist exactly:
// - assets/icon.ico
// - assets/icon.png
// - ui/index.html
//
//go:embed assets/icon.ico assets/icon.png ui/index.html
var assetsFS embed.FS

type Device struct {
	IP       string `json:"ip"`
	MAC      string `json:"mac"`
	Hostname string `json:"hostname,omitempty"`
}

var (
	host        string
	port        int
	allowOrigin string
	siteURL     string

	server   *http.Server
	listener net.Listener

	startupMenu *systray.MenuItem

	uiMu      sync.Mutex
	uiShowing bool
)

func main() {
	flag.StringVar(&host, "host", "127.0.0.1", "bind host")
	flag.IntVar(&port, "port", 8765, "bind port")
	flag.StringVar(&allowOrigin, "allow-origin", "http://spycamera.test", "allowed browser origin (CORS)")
	flag.StringVar(&siteURL, "site-url", "http://spycamera.test/scanner", "scanner website URL")
	flag.Parse()

	systray.Run(onReady, onExit)
}

func onReady() {
	// Tray icon (try preferred format; fallback to PNG always)
	if runtime.GOOS == "windows" {
		if b, err := assetsFS.ReadFile("assets/icon.ico"); err == nil && len(b) > 0 {
			systray.SetIcon(b)
		} else if b, err2 := assetsFS.ReadFile("assets/icon.png"); err2 == nil && len(b) > 0 {
			systray.SetIcon(b)
		} else {
			logf("tray icon missing: icoErr=%v pngErr=%v", err, err2)
		}
	} else {
		if b, err := assetsFS.ReadFile("assets/icon.png"); err == nil && len(b) > 0 {
			systray.SetIcon(b)
		} else {
			logf("tray icon missing: %v", err)
		}
	}

	systray.SetTitle("SpyCam Agent")
	systray.SetTooltip("SpyCam Agent running locally for network scan")

	// Start local API
	if err := startAgent(); err != nil {
		logf("Failed to start agent: %v", err)
	}

	// Menu items
	mOpenUI := systray.AddMenuItem("Open Agent Window", "Open the SpyCam Agent control window")
	mOpen := systray.AddMenuItem("Open Scanner Website", "Open the scanner page in your default browser")

	mHealth := systray.AddMenuItem(fmt.Sprintf("Agent: http://%s:%d", host, port), "Local agent endpoint")
	mHealth.Disable()

	systray.AddSeparator()

	startupMenu = systray.AddMenuItemCheckbox("Run on startup", "Start SpyCam Agent when you log in", false)
	enabled, _ := startupIsEnabled()
	if enabled {
		startupMenu.Check()
	} else {
		startupMenu.Uncheck()
	}

	mQuit := systray.AddMenuItem("Quit", "Stop agent and exit")

	go func() {
		for {
			select {
			case <-mOpenUI.ClickedCh:
				go showUiWindow()

			case <-mOpen.ClickedCh:
				_ = openURL(siteURL)

			case <-startupMenu.ClickedCh:
				if startupMenu.Checked() {
					_ = startupDisable()
					startupMenu.Uncheck()
				} else {
					_ = startupEnable()
					startupMenu.Check()
				}

			case <-mQuit.ClickedCh:
				systray.Quit()
				return
			}
		}
	}()
}

func onExit() {
	_ = stopAgent()
}

func showUiWindow() {
	uiMu.Lock()
	if uiShowing {
		uiMu.Unlock()
		return
	}
	uiShowing = true
	uiMu.Unlock()

	defer func() {
		uiMu.Lock()
		uiShowing = false
		uiMu.Unlock()
	}()

	htmlTplBytes, err := assetsFS.ReadFile("ui/index.html")
	if err != nil {
		logf("UI read failed: %v (did you embed ui/index.html?)", err)
		return
	}

	logoBytes, errLogo := assetsFS.ReadFile("assets/icon.png")
	if errLogo != nil {
		logf("Logo read failed: %v (did you embed assets/icon.png?)", errLogo)
		logoBytes = nil
	}

	logoB64 := ""
	if len(logoBytes) > 0 {
		logoB64 = base64.StdEncoding.EncodeToString(logoBytes)
	}

	html := strings.ReplaceAll(string(htmlTplBytes), "{{LOGO_BASE64}}", logoB64)

	w := webview.New(false)
	defer w.Destroy()

	w.SetTitle("SpyCam Agent")
	w.SetSize(460, 420, webview.HintNone)

	// --- JS bindings used by ui/index.html ---
	_ = w.Bind("openScanner", func() {
		_ = openURL(siteURL)
	})

	_ = w.Bind("hideUi", func() {
		// closes only the UI window, keeps tray/agent running
		w.Terminate()
	})

	_ = w.Bind("quitApp", func() {
		_ = stopAgent()
		systray.Quit()
	})

	_ = w.Bind("startupEnabled", func() bool {
		enabled, _ := startupIsEnabled()
		return enabled
	})

	_ = w.Bind("setStartupEnabled", func(enable bool) {
		if enable {
			_ = startupEnable()
			if startupMenu != nil {
				startupMenu.Check()
			}
		} else {
			_ = startupDisable()
			if startupMenu != nil {
				startupMenu.Uncheck()
			}
		}
	})

	_ = w.Bind("agentEndpoint", func() string {
		return fmt.Sprintf("http://%s:%d", host, port)
	})

	_ = w.Bind("agentHealth", func() map[string]any {
		return map[string]any{
			"ok":   server != nil,
			"os":   runtime.GOOS,
			"time": time.Now().Format(time.RFC3339),
		}
	})
	// --- end bindings ---

	w.SetHtml(html)
	w.Run()
}

func startAgent() error {
	addr := fmt.Sprintf("%s:%d", host, port)

	mux := http.NewServeMux()
	mux.HandleFunc("/health", func(w http.ResponseWriter, r *http.Request) {
		cors(w, allowOrigin)
		if r.Method == http.MethodOptions {
			w.WriteHeader(http.StatusNoContent)
			return
		}
		_ = json.NewEncoder(w).Encode(map[string]any{
			"ok":   true,
			"os":   runtime.GOOS,
			"time": time.Now().Format(time.RFC3339),
		})
	})

	mux.HandleFunc("/scan", func(w http.ResponseWriter, r *http.Request) {
		cors(w, allowOrigin)
		if r.Method == http.MethodOptions {
			w.WriteHeader(http.StatusNoContent)
			return
		}
		devs, err := scanNeighbors()
		if err != nil {
			http.Error(w, err.Error(), 500)
			return
		}
		_ = json.NewEncoder(w).Encode(map[string]any{
			"devices": devs,
			"os":      runtime.GOOS,
			"at":      time.Now().Format(time.RFC3339),
		})
	})

	var err error
	listener, err = net.Listen("tcp", addr)
	if err != nil {
		return err
	}

	server = &http.Server{Addr: addr, Handler: mux}
	go func() { _ = server.Serve(listener) }()

	return nil
}

func stopAgent() error {
	if server == nil {
		return nil
	}
	ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
	defer cancel()

	_ = server.Shutdown(ctx)
	server = nil

	if listener != nil {
		_ = listener.Close()
		listener = nil
	}
	return nil
}

func cors(w http.ResponseWriter, allowOrigin string) {
	w.Header().Set("Access-Control-Allow-Origin", allowOrigin)
	w.Header().Set("Access-Control-Allow-Methods", "GET, OPTIONS")
	w.Header().Set("Access-Control-Allow-Headers", "Content-Type")
	w.Header().Set("Content-Type", "application/json")
}

func openURL(url string) error {
	// Try pkg/browser first
	if err := browser.OpenURL(url); err == nil {
		return nil
	}

	// Fallbacks
	switch runtime.GOOS {
	case "windows":
		return exec.Command("rundll32", "url.dll,FileProtocolHandler", url).Start()
	case "darwin":
		return exec.Command("open", url).Start()
	default:
		return exec.Command("xdg-open", url).Start()
	}
}

func scanNeighbors() ([]Device, error) {
	switch runtime.GOOS {
	case "windows":
		out, err := exec.Command("arp", "-a").CombinedOutput()
		if err != nil {
			return nil, fmt.Errorf("arp -a failed: %v", err)
		}
		return parseWindowsArp(string(out)), nil
	default:
		out, _ := exec.Command("sh", "-lc", "ip neigh 2>/dev/null || arp -a 2>/dev/null || true").CombinedOutput()
		return parseUnixNeighbors(string(out)), nil
	}
}

func parseWindowsArp(raw string) []Device {
	raw = strings.ReplaceAll(raw, "\r", "\n")
	lines := strings.Split(raw, "\n")
	seen := map[string]bool{}
	var devs []Device

	for _, ln := range lines {
		ln = strings.TrimSpace(ln)
		f := strings.Fields(ln)
		if len(f) < 2 {
			continue
		}
		ip := f[0]
		mac := strings.ToLower(strings.ReplaceAll(f[1], "-", ":"))
		if !looksLikeIPv4(ip) || !looksLikeMAC(mac) {
			continue
		}
		key := ip + "|" + mac
		if seen[key] {
			continue
		}
		seen[key] = true
		devs = append(devs, Device{IP: ip, MAC: mac})
	}

	return devs
}

func parseUnixNeighbors(raw string) []Device {
	raw = strings.ReplaceAll(raw, "\r", "\n")
	lines := strings.Split(raw, "\n")
	seen := map[string]bool{}
	var devs []Device

	for _, ln := range lines {
		ln = strings.TrimSpace(ln)
		if ln == "" {
			continue
		}

		if strings.Contains(ln, "lladdr") {
			f := strings.Fields(ln)
			if len(f) < 5 {
				continue
			}
			ip := f[0]
			mac := ""
			for i := 0; i < len(f); i++ {
				if f[i] == "lladdr" && i+1 < len(f) {
					mac = strings.ToLower(f[i+1])
					break
				}
			}
			if !looksLikeIPv4(ip) || !looksLikeMAC(mac) {
				continue
			}
			key := ip + "|" + mac
			if seen[key] {
				continue
			}
			seen[key] = true
			devs = append(devs, Device{IP: ip, MAC: mac})
			continue
		}

		if strings.Contains(ln, "(") && strings.Contains(ln, ")") && strings.Contains(ln, " at ") {
			ip := between(ln, "(", ")")
			parts := strings.SplitN(ln, " at ", 2)
			if len(parts) != 2 {
				continue
			}
			m := strings.Fields(parts[1])
			if len(m) == 0 {
				continue
			}
			mac := strings.ToLower(m[0])
			if !looksLikeIPv4(ip) || !looksLikeMAC(mac) {
				continue
			}
			key := ip + "|" + mac
			if seen[key] {
				continue
			}
			seen[key] = true
			devs = append(devs, Device{IP: ip, MAC: mac})
		}
	}

	return devs
}

func between(s, a, b string) string {
	i := strings.Index(s, a)
	j := strings.Index(s, b)
	if i == -1 || j == -1 || j <= i {
		return ""
	}
	return s[i+len(a) : j]
}

func looksLikeIPv4(s string) bool {
	ip := net.ParseIP(s)
	return ip != nil && strings.Count(s, ".") == 3
}

func looksLikeMAC(s string) bool {
	if s == "" {
		return false
	}
	parts := strings.Split(strings.ReplaceAll(s, "-", ":"), ":")
	if len(parts) != 6 {
		return false
	}
	for _, p := range parts {
		if len(p) != 2 {
			return false
		}
	}
	return true
}

// Writes to: %APPDATA%\SpyCam\spycam-agent.log
func logf(format string, args ...any) {
	dir, err := os.UserConfigDir()
	if err != nil {
		return
	}
	p := filepath.Join(dir, "SpyCam", "spycam-agent.log")
	_ = os.MkdirAll(filepath.Dir(p), 0755)

	f, err := os.OpenFile(p, os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0644)
	if err != nil {
		return
	}
	defer f.Close()

	_, _ = fmt.Fprintf(f, time.Now().Format(time.RFC3339)+" "+format+"\n", args...)
}